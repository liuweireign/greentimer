/*
 * Copyright 2007 Stephen Liu
 * For license terms, see the file COPYING along with this library.
 */

#ifndef __spgcrypt_h__
#define __spgcrypt_h__

#ifdef __cplusplus
extern "C" {
#endif

int sp_init_gcrypt_pthread();

#ifdef __cplusplus
}
#endif

#endif

